<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '98fdfd3dd94ebfd3ecedf894517c60bb',
      'native_key' => 'elfinderx',
      'filename' => 'modNamespace/836e0fb36a03ba6007a02701828d47d6.vehicle',
      'namespace' => 'elfinderx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '53e6ad53a9778383b682acbe490fff2f',
      'native_key' => 1,
      'filename' => 'modCategory/e956afcf8d586b04544641fecff61a49.vehicle',
      'namespace' => 'elfinderx',
    ),
  ),
);